/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { ensureLazyModule } from '../../loader';
import { Wid } from '../../whatsapp';
import { sendRevokeGroupInviteCode } from '../../whatsapp/functions';
import { ensureGroup } from '.';

/**
 * Revoke the current invite code and generate new one.
 *
 * @example
 * ```javascript
 * const code = WPP.group.revokeInviteCode('[group-id]@g.us');
 * const link = 'https://chat.whatsapp.com/' + code;
 * ```
 *
 * @category Group
 */
export async function revokeInviteCode(groupId: string | Wid) {
  const groupChat = await ensureGroup(groupId, true);

  /**
   * `WAWebGroupInviteJob` ships in the same on-demand bundle as
   * `WAWebMexFetchGroupInviteCodeJob` (see getInviteCode.ts), so it is
   * missing for the same reason: a session that never opens the group
   * "Invite via link" drawer never fetches it.
   */
  await ensureLazyModule('WAWebGroupInviteJob');

  return await sendRevokeGroupInviteCode(groupChat.id);
}

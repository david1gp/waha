/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import * as fs from 'fs';
import fetch from 'node-fetch';
import * as path from 'path';
import { JSDoc, Node, Project } from 'ts-morph';

import * as wpp from '../';
import { getPage } from './browser';

declare global {
  interface Window {
    WPP: typeof wpp;
  }
}

export const DIR_BASE = path.resolve(__dirname, '../../src/whatsapp');
const dirs = [''];

dirs.push(
  ...fs
    .readdirSync(DIR_BASE, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
);

async function start() {
  const { browser, page } = await getPage();

  page.addInitScript(() => {
    setInterval(() => {
      (window as any).wppForceMainLoad = true;
    }, 500);
  });

  /**
   * Fail fast when WhatsApp Web never boots its module system — e.g. the
   * static assets of old versions get purged from Meta's CDN (HTTP 404) and
   * the page stalls on the splash screen forever.
   */
  const booted = await page
    .waitForFunction(
      () =>
        ((window as any).__d && (window as any).require) ||
        ((window as any).webpackChunkwhatsapp_web_client || []).length > 0,
      null,
      { timeout: 90_000 }
    )
    .catch(() => null);

  if (!booted) {
    console.error(
      'WhatsApp Web failed to boot (no module system after 90s); ' +
        'the assets of this version may have been removed from the CDN'
    );
    process.exit(3);
  }

  await page.waitForFunction(() => window.WPP?.isFullReady, null, {
    timeout: 0,
  });

  page.on('console', (message) => {
    if (message.type() !== 'debug') {
      console.log('browser', message.type(), message.text());
    }
  });

  // Verify lazy bindings after requesting their bundles; they must still
  // resolve below, so a removed export or broken finder remains a failure.
  await page.evaluate(async () => {
    for (const moduleId of [
      'WAWebGenerateEventCallLink',
      'WAWebGroupGetCommunityParticipantsJob',
      'WAWebSetPrivacyForOneCategoryAction',
    ]) {
      await window.WPP.loader.ensureLazyModule(moduleId);
    }
  });

  const result = await page.evaluate((dirs: string[]) => {
    const result: any = {};

    const modules: any = window.WPP.whatsapp as any;

    for (const dir of dirs) {
      const submodules = dir ? modules[dir] : modules;
      if (!submodules) {
        continue;
      }

      for (const name of Object.keys(submodules)) {
        let module: any;
        try {
          module = submodules[name];
        } catch (_error) {}

        const resultName = dir ? `${dir}.${name}` : name;

        result[resultName] = window.WPP.whatsapp._moduleIdMap.get(module);
      }
    }

    return result;
  }, dirs);

  const version = await page
    .evaluate(() => (window as any).Debug.VERSION)
    .catch(() => null);

  // if any pending request is hanging we unroute them to avoid errors, before browser close
  await page.unrouteAll({ behavior: 'ignoreErrors' });

  await browser.close();

  delete result['_moduleIdMap'];
  for (const dir of dirs) {
    delete result[dir];
  }

  let exitCode = 0;
  /**
   * Theses modules only loaded after device is connected
   * I be creating other function for check expires based directily from files
   * This will not directly affect the function call, it continues to work normally.
   */
  const ignoreFailModules: string[] = [
    // Older builds retain img/imgFull model properties instead of the native
    // thumb getters. getProfilePictureUrl explicitly covers that fallback.
    'functions.getImg',
    'functions.getImgFull',
    // Removed from native list mutations on recent WA builds; older versions
    // still enforce it through lists/assertListEditingAvailable.
    'functions.labelsEditingEnabled',
    'enums.StreamInfo', // Plain TypeScript enum, not a webpack module
    'enums.StreamMode', // Plain TypeScript enum, not a webpack module
    'functions.createCollection',
    'functions.deleteCollection',
    'functions.editCollection',
    // Both forward modules ship in a resource bundle WhatsApp's Bootloader only
    // fetches on demand, so they are legitimately unresolved on a session that
    // never forwards. `WPP.chat.forwardMessage(s)` load it through
    // `ensureLazyModule()` before use (see src/loader/lazyModules.ts).
    'functions.forwardMessages',
    'functions.forwardMessagesToChats',
    'functions.setPushname',
    'functions.revokeStatus',
    'functions.muteNewsletter', // removed in version 2.3000.1032373751
    'functions.unmuteNewsletter', // removed in version 2.3000.1032373751
    'functions.toggleNewsletterAdminActivityMuteStateAction', // new in version >= 2.3000.1032373751
    'functions.msgFindQuery', // stopped working in WA version ~2.3000.1034162388
    'functions.msgFindBefore', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindAfter', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindByDirection', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindCallLog', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindEvents', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindMedia', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindSearch', // added in WA version 2.3000.1034162388, but not available in older versions
    'functions.msgFindStarred', // added in WA version 2.3000.1034162388, but not available in older versions
    'CartItemCollection', // WAWebCartItemCollection removed from WA ~= 2.3000.1039092809
    'functions.subscribeGroupPresence', // added in WAWebContactPresenceBridge >= ~2.3000.1039447205
    'functions.getUserhash', // removed from WAWebContactGetters in WA ~2.3000.1043126001, reimplemented in src/contact/patch.ts
    'Constants', // WAWebConstantsDeprecated removed from WA ~= 2.3000.1044096409
    // WAWebConnGetters was introduced in WA ~2.3000.1045643679; every older
    // version still exposes isSMB directly on Conn, so the miss is expected
    // there (src/whatsapp/misc/ConnGetters.ts falls back to Conn.isSMB).
    'ConnGetters',
    'functions.createGroup', // WAWebGroupCreateJob only registers after login on WA >= ~2.3000.1044096409
    // WAWebGroupCommunityJob moved into an on-demand resource bundle in WA
    // ~2.3000.1045986927 and only `.react` community flows pull it, so it is
    // unresolved on this test (which never logs in). `WPP.community.*` loads
    // it through `ensureCommunityJob()` before use.
    'functions.sendCreateCommunity',
    'functions.sendDeactivateCommunity',
    'functions.sendLinkSubgroups',
    'functions.sendUnlinkSubgroups',
    // The group invite-code modules load lazily and are not registered on the
    // QR screen on WA >= ~2.3000.1040 (this test never logs in)
    'functions.joinGroupViaInvite',
    'functions.queryGroupInviteCode',
    'functions.resetGroupInviteCode',
  ];

  for (const moduleName of Object.keys(result)) {
    if (!result[moduleName] && !ignoreFailModules.includes(moduleName)) {
      if (
        process.env['SEND_WEBHOOK_FAILURE'] &&
        process.env['DISCORD_WEBHOOK_URL_FAILURE']
      ) {
        const message = {
          content: `**Alert:**\nModule not found: ${moduleName}. v: ${version}\n\n See more at: ${process.env['URL_ACTION']}`,
        };

        await fetch(process.env['DISCORD_WEBHOOK_URL_FAILURE'], {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(message),
        }).catch((error) =>
          console.error('Error on send message to discord:', error)
        );
      }
      exitCode = 1;
      console.error(`Module not found: ${moduleName}`);
    }
  }

  if (!process.argv.includes('--dry-run')) {
    const project = new Project({
      tsConfigFilePath: path.resolve(__dirname, '../../tsconfig.json'),
    });

    for (const dir of dirs) {
      const filePath = `${DIR_BASE}${dir ? '/' + dir : ''}/index.ts`;

      const mainFile = project.getSourceFileOrThrow(filePath);

      for (const [name, declarations] of mainFile.getExportedDeclarations()) {
        const resultName = dir ? `${dir}.${name}` : name;

        if (!result[resultName]) {
          continue;
        }

        const moduleID = `${result[resultName]}`;
        if (!moduleID) {
          continue;
        }

        for (const d of declarations) {
          let docs: JSDoc[] = [];

          if (Node.isJSDocable(d)) {
            docs = d.getJsDocs();
            if (!docs.length) {
              d.addJsDoc('\n');
              docs = d.getJsDocs();
            }
          } else if (Node.isVariableDeclaration(d)) {
            const parent = d.getParent().getParent();

            if (!parent || !Node.isJSDocable(parent)) {
              continue;
            }

            docs = parent.getJsDocs();
            if (!docs.length) {
              parent.addJsDoc('\n');
              docs = parent.getJsDocs();
            }
          } else {
            continue;
          }

          if (!docs.length) {
            continue;
          }
          const tags = docs[0].getTags() || [];
          let hasID = false;

          for (const tag of tags) {
            const currId = (tag.getCommentText() || '').split(' ')[0];

            if (moduleID === currId) {
              hasID = true;
            }
          }
          if (!hasID) {
            docs[0].addTag({
              tagName: 'whatsapp',
              text: `${moduleID} >= ${version}`,
            });
          }
        }
      }
    }

    await project.save();
  }

  process.exit(exitCode);
}
start();

/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { getMyUserWid } from '../conn/functions/getMyUserWid';
import { WPPError } from '../util';
import { CatalogStore, ProductModel } from '../whatsapp';

export class InvalidProduct extends WPPError {
  constructor(readonly id: string) {
    super('product_not_found', `Product not found for ${id}`);
  }
}
export async function assertGetProduct(
  productId: string
): Promise<ProductModel> {
  const product = await CatalogStore.findProduct({
    catalogWid: getMyUserWid(),
    productId: productId,
  });
  const Product = product[0].msgProductCollection._index[productId];

  if (!Product) {
    throw new InvalidProduct(productId);
  }

  return Product;
}

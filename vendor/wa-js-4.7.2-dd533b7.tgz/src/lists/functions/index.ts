/*!
 * Copyright 2026 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export { addChats } from './addChats';
export { create } from './create';
export { getColorPalette } from './getColorPalette';
export { list, ListInfo } from './list';
export { remove } from './remove';
export { removeChats } from './removeChats';
export { rename } from './rename';
export { ListColor } from './resolveColorIndex';
export { setColor } from './setColor';
export { setOrder } from './setOrder';

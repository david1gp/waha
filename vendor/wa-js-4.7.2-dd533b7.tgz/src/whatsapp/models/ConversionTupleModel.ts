/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { exportProxyModel } from '../exportModule';
import { Wid } from '../misc';
import {
  Model,
  ModelOptions,
  ModelPropertiesContructor,
  ModelProxy,
} from './Model';

interface Props {
  id: Wid;
  conversionData?: any;
  conversionSource?: any;
  timestamp?: any;
}

interface Session {
  stale?: any;
  alarmId?: any;
}

interface Derived {}

/** @whatsapp 18787
 * @whatsapp 118787 >= 2.2222.8
 */
export declare interface ConversionTupleModel extends ModelProxy<
  Props,
  Session,
  Derived
> {}

/** @whatsapp 18787
 * @whatsapp 118787 >= 2.2222.8
 */
export declare class ConversionTupleModel extends Model {
  idClass: typeof Wid;
  constructor(
    proterties?: ModelPropertiesContructor<ConversionTupleModel>,
    options?: ModelOptions
  );
  elapsedSeconds(): any;
  formatTuple(): any;
  getCollection(): any;
}

exportProxyModel(exports, 'ConversionTupleModel');

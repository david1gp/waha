/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import * as loader from '../../loader';
import { Wid } from '..';
import { exportModule } from '../exportModule';
import { resetGroupInviteCode } from './resetGroupInviteCode';

/** @whatsapp 69586
 * @whatsapp 769586 >= 2.2222.8
 */
export declare function sendRevokeGroupInviteCode(
  groupId: Wid
): Promise<string>;

exportModule(
  exports,
  {
    sendRevokeGroupInviteCode: 'sendRevokeGroupInviteCode',
  },
  (m) => m.sendRevokeGroupInviteCode
);

/**
 * @whatsapp >= 2.2301.5
 */
loader.injectFallbackModule('sendRevokeGroupInviteCode', {
  sendRevokeGroupInviteCode: async (groupId: Wid) => {
    return await resetGroupInviteCode(groupId).then((value) => value.code);
  },
});

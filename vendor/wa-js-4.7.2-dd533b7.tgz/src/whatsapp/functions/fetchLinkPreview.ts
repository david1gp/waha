/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import * as loader from '../../loader';
import { exportModule } from '../exportModule';

export interface LinkUrlData {
  anchor: undefined;
  domain?: string;
  href: string;
  index: number;
  input: string;
  isHttp: boolean;
  params?: string;
  path?: string;
  port?: number;
  scheme: string;
  suspiciousCharacters?: string;
  url: string;
  username?: string;
}

export interface LinkPreviewResult {
  url: string;
  data: {
    title?: string;
    description?: string;
    canonicalUrl?: string;
    matchedText: string;
    richPreviewType: number;
    thumbnail?: string;
    doNotPlayInline: boolean;
  };
}

/** @whatsapp 19146
 * @whatsapp 75820 >= 2.2204.13
 * @whatsapp 519146 >= 2.2222.8
 * @whatsapp 632590 >= 2.2228.4
 */
export declare function fetchLinkPreview(
  url: LinkUrlData
): Promise<null | LinkPreviewResult>;

exportModule(
  exports,
  {
    fetchLinkPreview: [
      'getLinkPreview', // @whatsapp >= 2.2329.7
      'default', // @whatsapp < 2.2329.7
    ],
  },
  (m, id) => {
    // @whatsapp >= 2.2329.7
    if (m.getLinkPreview && !m.getAck) {
      return true;
    }
    // @whatsapp < 2.2329.7
    const source: string = loader.moduleSource(id);
    return (
      source.includes('.genMinimalLinkPreview') &&
      source.includes('.getProductOrCatalogLinkPreview')
    );
  }
);

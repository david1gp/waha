/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { exportModule } from '../exportModule';
import { MsgKey } from '../misc';
import { ChatModel } from '../models';

/**
 * Send the read receipt up to the specified message of the chat
 *
 * @whatsapp WAWebSendReadReceiptJob
 */
export declare function markChatRead(
  chat: ChatModel,
  msgKey: MsgKey,
  threadId?: string | null
): Promise<void>;

exportModule(
  exports,
  {
    markChatRead: 'markChatRead',
  },
  (m) => m.markChatRead && m.markStatusRead && m.sendAddOnReadReceipts
);

/**
 * @whatsapp WAWebDBPendingReadReceiptQueries
 */
export declare function queryPendingReadReceiptMsgRows(
  chatId: string,
  threadId?: string | null
): Promise<{ id: string }[]>;

exportModule(
  exports,
  { queryPendingReadReceiptMsgRows: 'queryPendingReadReceiptMsgRows' },
  (m) => typeof m.queryPendingReadReceiptMsgRows === 'function'
);

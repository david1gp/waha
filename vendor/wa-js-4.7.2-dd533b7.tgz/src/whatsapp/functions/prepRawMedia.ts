/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { MediaPrep, OpaqueData } from '..';
import { exportModule } from '../exportModule';

/**
 * Moved out of WAWebMediaPrep into WAWebPrepRawMedia on recent versions.
 *
 * @whatsapp WAWebPrepRawMedia
 * @whatsapp 78986
 * @whatsapp 778986 >= 2.2222.8
 */
export declare function prepRawMedia(
  data: OpaqueData,
  options: {
    isPtt?: boolean;
    asDocument?: boolean;
    asGif?: boolean;
    isAudio?: boolean;
    asSticker?: boolean;
    maxDimension?: number;
    filename?: string;
  }
): MediaPrep;

exportModule(
  exports,
  {
    prepRawMedia: 'prepRawMedia',
  },
  (m) => m.prepRawMedia
);

/*!
 * Copyright 2024 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Debug from 'debug';

import * as loader from '../../loader';
import { WPPError } from '../../util';
import { websocket } from '../../whatsapp';
import { DROP_ATTR } from '../../whatsapp/contants';
import { wrapModuleFunction } from '../../whatsapp/exportModule';
import {
  createFanoutMsgStanza,
  createMsgProtobuf,
  deprecatedSendStanzaAndReturnAck,
  encodeMaybeMediaType,
  encryptAndSendSenderKeyMsg,
  getABPropConfigValue,
  mediaTypeFromProtobuf,
  typeAttributeFromProtobuf,
} from '../../whatsapp/functions';
import { RawMessage } from '..';
import { encryptAndParserMsgButtons } from './buttonsParser';
import {
  createNativeFlowButtons,
  MessageButtonsTypes,
} from './createNativeFlowButtons';
import {
  applyGroupListStanza,
  applyNativeFlowBiz,
  detectCarousel,
  detectList,
  detectNativeFlow,
  NativeFlowBizExperiment,
  summarizeBiz,
  unwrapKnownMessage,
} from './nativeFlowBiz';

const debug = Debug('WA-JS:native-flow');

export type { MessageButtonsTypes } from './createNativeFlowButtons';

export interface MessageButtonsOptions {
  /**
   * List of buttons, with at least 1 option and a maximum of 3
   */
  buttons?: Array<MessageButtonsTypes>;
  /**
   * Title for buttons, only for text message
   */
  title?: string;
  /**
   * Footer text for buttons
   */
  footer?: string;
  /**
   * Experimental variations of the `<biz>` node sent with the buttons, only
   * to test what WhatsApp accepts. Not validated; leave undefined in production.
   */
  experimentalNativeFlowBiz?: NativeFlowBizExperiment;
}

/**
 * Prepare a message for buttons
 *
 * @category Message
 * @internal
 */

export function prepareMessageButtons<T extends RawMessage>(
  message: T,
  options: MessageButtonsOptions
): T {
  if (!options.buttons) {
    return message;
  }

  const nativeFlow = createNativeFlowButtons(options.buttons);
  const headerMediaType = getInteractiveHeaderMediaType(message.type);

  if (message.type !== 'chat' && nativeFlow.buttons.length > 2) {
    throw new WPPError(
      'not_alowed_more_then_three_buttons',
      'Not allowed more then three buttons in file messages'
    );
  }

  message.title = options.title;
  message.footer = options.footer;
  message.caption = message.body || message.caption || ' ';
  message.type = 'interactive';
  message.interactiveType = 'native_flow';
  message.nativeFlowInteractiveMsg = true;
  message.interactiveHeader = {
    title: options.title,
    hasMediaAttachment: Boolean(headerMediaType),
    ...(headerMediaType ? { mediaType: headerMediaType } : {}),
  };

  message.nativeFlowName = nativeFlow.name;
  if (options.experimentalNativeFlowBiz) {
    (message as any).nativeFlowBizExperiment =
      options.experimentalNativeFlowBiz;
  }
  message.interactivePayload = {
    buttons: nativeFlow.buttons,
    messageVersion: 1,
  };

  return message;
}

function getInteractiveHeaderMediaType(
  type?: string
): 'DOCUMENT' | 'IMAGE' | 'VIDEO' | undefined {
  switch (type) {
    case 'document':
      return 'DOCUMENT';
    case 'image':
      return 'IMAGE';
    case 'video':
      return 'VIDEO';
    default:
      return undefined;
  }
}

/**
 * Completes the `<biz>` node of an initial Native Flow / carousel stanza and
 * logs a sanitized summary (when the `WA-JS:native-flow` debug is enabled).
 */
function completeNativeFlowBiz(
  content: unknown,
  proto: any,
  record: any,
  chatWid: any,
  via: string
): boolean {
  const experiment: NativeFlowBizExperiment | undefined =
    record?.data?.nativeFlowBizExperiment ?? record?.nativeFlowBizExperiment;
  const carousel = detectCarousel(proto);
  const nativeFlow =
    detectNativeFlow(proto) ||
    (carousel ? { kind: 'interactive' as const, path: carousel.path } : null);

  if (nativeFlow) {
    const result = applyNativeFlowBiz(
      content,
      nativeFlow.kind,
      (tag, attrs, c) => websocket.smax(tag, attrs, c),
      experiment
    );
    let isGroup = false;
    try {
      isGroup = Boolean((chatWid ?? record?.data?.to)?.isGroup?.());
    } catch {
      // diagnostics only
    }
    debug(
      'native_flow via=%s group=%s addon=%s wrappers=%s result=%s experiment=%s envelope=%s',
      via,
      isGroup,
      nativeFlow.kind,
      nativeFlow.path.join('>') || '-',
      result,
      experiment ? JSON.stringify(experiment) : '-',
      summarizeBiz(content)
    );
    return true;
  }

  if (experiment) {
    // Field names only (no values), to find where the experiment is lost
    const { message, path } = unwrapKnownMessage(proto);
    debug(
      'native_flow experiment set but not detected: proto=%s wrappers=%s message=%s interactive=%s',
      Object.keys(proto || {}).join(','),
      path.join('>') || '-',
      Object.keys(message || {}).join(','),
      Object.keys(message?.interactiveMessage || {}).join(',')
    );
  }

  return false;
}

// Group messages sent with a sender key do not go through
// `createFanoutMsgStanza`: WhatsApp builds the stanza inside
// `encryptAndSendSenderKeyMsg` and sends it right away. The context is kept
// only while that function runs, keyed by destination and message id so concurrent
// sends cannot apply another message's envelope.
const pendingGroupSends = new Map<
  string,
  { proto: any; record: any; kind: 'native-flow' | 'list' }
>();

function groupSendKey(id: any, to: any): string | undefined {
  const messageId = typeof id === 'string' ? id : id?.id;
  const destination = to?.toString();
  if (typeof messageId !== 'string' || !messageId || !destination) return;
  return JSON.stringify([destination, messageId]);
}

loader.onFullReady(() => {
  wrapModuleFunction(createMsgProtobuf, (func, ...args) => {
    const [message] = args;
    const r = func(...args);
    if (message.interactiveMessage?.nativeFlowMessage?.buttons !== undefined) {
      const mediaPart = [
        'documentMessage',
        'documentWithCaptionMessage',
        'imageMessage',
        'locationMessage',
        'videoMessage',
      ];
      for (let part of mediaPart) {
        if (part in r) {
          const partName = part;
          if (part === 'documentWithCaptionMessage') part = 'documentMessage';

          message.interactiveMessage.header = {
            ...message.interactiveMessage.header,
            [`${part}`]: r[partName]?.message?.documentMessage || r[partName],
            hasMediaAttachment: true,
          };
          delete r[partName];
          break;
        }
      }
      if (typeof r.extendedTextMessage !== 'undefined')
        delete r.extendedTextMessage;
      if (typeof r.conversation !== 'undefined') delete r.conversation;
      r.viewOnceMessage = {
        message: {
          interactiveMessage: message.interactiveMessage,
        },
      };
    }
    return r;
  });

  wrapModuleFunction(encodeMaybeMediaType, (func, ...args) => {
    const [type] = args;
    if (type === 'button') {
      return DROP_ATTR;
    }
    return func(...args);
  });

  wrapModuleFunction(mediaTypeFromProtobuf, (func, ...args) => {
    const [proto] = args;
    if (
      proto.documentWithCaptionMessage?.message?.templateMessage
        ?.hydratedTemplate
    ) {
      return func(
        proto.documentWithCaptionMessage?.message?.templateMessage
          ?.hydratedTemplate
      );
    }
    return func(...args);
  });

  wrapModuleFunction(typeAttributeFromProtobuf, (func, ...args) => {
    const [proto] = args;

    if (proto?.viewOnceMessage?.interactiveMessage) {
      const keys = Object.keys(proto?.viewOnceMessage?.interactiveMessage);

      const messagePart = [
        'documentMessage',
        'documentWithCaptionMessage',
        'imageMessage',
        'locationMessage',
        'videoMessage',
      ];

      if (messagePart.some((part) => keys.includes(part))) {
        return 'media';
      }

      return 'text';
    } else if (
      proto?.documentWithCaptionMessage?.message?.templateMessage
        ?.hydratedTemplate
    ) {
      const keys = Object.keys(
        proto?.documentWithCaptionMessage?.message?.templateMessage
          ?.hydratedTemplate
      );

      const messagePart = [
        'documentMessage',
        'imageMessage',
        'locationMessage',
        'videoMessage',
      ];

      if (messagePart.some((part) => keys.includes(part))) {
        return 'media';
      }

      return 'text';
    }

    if (
      proto?.buttonsMessage?.headerType === 1 ||
      proto?.buttonsMessage?.headerType === 2
    ) {
      return 'text';
    }

    return func(...args);
  });

  wrapModuleFunction(createFanoutMsgStanza, async (func, ...wrapArgs) => {
    let buttonNode: websocket.WapNode | null = null;

    const args: any[] = wrapArgs;

    // WhatsApp >= 2.3000.1043786062 uses a single named-params object
    const namedParams: any =
      args.length === 1 && typeof args[0]?.msgProtobuf !== 'undefined'
        ? args[0]
        : null;

    const proto: any = namedParams
      ? namedParams.msgProtobuf
      : args[1].id
        ? args[2]
        : args[1];

    if (proto.buttonsMessage) {
      buttonNode = websocket.smax('buttons');
    } else if (proto.listMessage) {
      // The trick to send list message is to force the 'product_list' type in the biz node
      // const listType: number = proto.listMessage.listType || 0;
      const listType = 2;

      const types = ['unknown', 'single_select', 'product_list'];

      buttonNode = websocket.smax('list', {
        v: '2',
        type: types[listType],
      });
    }

    let node = await (func as (...args: any[]) => any)(...args);
    if (proto?.viewOnceMessage?.message?.interactiveMessage) {
      if (namedParams) {
        const positionalToNamed = (
          message: any,
          msgProtobuf: any,
          deviceList: any,
          option: any,
          metricReporter: any,
          groupData: any
        ) =>
          func({
            ...namedParams,
            msgRecord: message,
            msgProtobuf,
            deviceList,
            option,
            metricReporter,
            groupData,
          });

        node = await encryptAndParserMsgButtons(
          namedParams.msgRecord,
          namedParams.msgProtobuf,
          namedParams.deviceList,
          namedParams.option,
          namedParams.metricReporter,
          namedParams.groupData,
          positionalToNamed
        );
      } else {
        node = await (encryptAndParserMsgButtons as any)(...args, func);
      }
    }

    const content =
      (node.content as websocket.WapNode[]) || (node as any).stanza?.content;

    if (!buttonNode) {
      // Initial Native Flow and carousel messages (responses and legacy are not matched)
      const record: any = namedParams ? namedParams.msgRecord : args[0];
      completeNativeFlowBiz(
        content,
        proto,
        record,
        namedParams?.chatId,
        'fanout'
      );
      return node;
    }

    let bizNode = content.find((c) => c.tag === 'biz');

    if (!bizNode) {
      bizNode = websocket.smax('biz', {}, null);
      content.push(bizNode);
    }

    let hasButtonNode = false;

    if (Array.isArray(bizNode.content)) {
      hasButtonNode = !!bizNode.content.find((c) => c.tag === buttonNode?.tag);
    } else {
      bizNode.content = [];
    }

    if (!hasButtonNode) {
      bizNode.content.push(buttonNode);
    }

    return node;
  });

  wrapModuleFunction(encryptAndSendSenderKeyMsg, async (func, ...wrapArgs) => {
    const args: any[] = wrapArgs;
    // The protobuf is the 2nd argument in current WhatsApp versions and the 3rd
    // in older ones
    const proto = [args[1], args[2]].find(
      (p) => p && (detectNativeFlow(p) || detectCarousel(p) || detectList(p))
    );

    if (!proto) {
      return (func as (...a: any[]) => any)(...args);
    }

    const record = args[0];
    const data = record?.data ?? record;
    const key = groupSendKey(data?.id, data?.to ?? data?.id?.remote);
    if (!key) {
      debug('native_flow sender-key missing message correlation key');
      return (func as (...a: any[]) => any)(...args);
    }
    const context = {
      proto,
      record,
      kind: detectList(proto) ? ('list' as const) : ('native-flow' as const),
    };
    pendingGroupSends.set(key, context);

    try {
      return await (func as (...a: any[]) => any)(...args);
    } finally {
      if (pendingGroupSends.get(key) === context) {
        pendingGroupSends.delete(key);
      }
    }
  });

  wrapModuleFunction(deprecatedSendStanzaAndReturnAck, (func, ...args) => {
    const stanza: any = args[0];
    const key = groupSendKey(stanza?.attrs?.id, stanza?.attrs?.to);
    const context = key ? pendingGroupSends.get(key) : undefined;

    if (context && stanza?.tag === 'message') {
      pendingGroupSends.delete(key!);
      try {
        if (context.kind === 'list') {
          const result = applyGroupListStanza(stanza, (tag, attrs, c) =>
            websocket.smax(tag, attrs, c)
          );
          debug(
            'list via=sender-key group=true result=%s envelope=%s',
            result,
            summarizeBiz(stanza.content)
          );
        } else {
          completeNativeFlowBiz(
            stanza.content,
            context.proto,
            context.record,
            undefined,
            'sender-key'
          );
        }
      } catch (error) {
        debug('native_flow sender-key biz failed: %O', error);
      }
    }

    return (func as (...a: any[]) => any)(...args);
  });

  wrapModuleFunction(getABPropConfigValue, (func, ...args) => {
    const [key] = args;
    switch (key) {
      case 'web_unwrap_message_for_stanza_attributes':
        return false;
      /*case 'enable_web_calling':
        return true;*/
    }
    return func(...args);
  });
});

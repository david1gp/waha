/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Debug from 'debug';

import { assertFindChat } from '../../assert';
import * as loader from '../../loader';
import {
  blobToArrayBuffer,
  convertToFile,
  createWid,
  getVideoInfoFromBuffer,
  WPPError,
} from '../../util';
import {
  formatFileSize,
  getMediaTypeForValidation,
} from '../../util/fileHelpers';
import * as whatsapp from '../../whatsapp';
import {
  ChatModel,
  lidPnCache,
  MsgKey,
  MsgModel,
  OpaqueData,
  StatusV3Store,
  Wid,
} from '../../whatsapp';
import { SendMsgResult } from '../../whatsapp/enums';
import { wrapModuleFunction } from '../../whatsapp/exportModule';
import {
  generateVideoThumbsAndDuration,
  isAnimatedWebp,
  prepRawMedia,
  processRawSticker,
  STATUS_JID,
  uploadMedia,
} from '../../whatsapp/functions';
import {
  defaultSendMessageOptions,
  RawMessage,
  SendMessageOptions,
  SendMessageReturn,
} from '..';
import {
  getMessageById,
  markIsRead,
  MessageButtonsOptions,
  prepareMessageButtons,
  prepareRawMessage,
} from '.';
import { prepareAudioWaveform } from './prepareAudioWaveform';

const debug = Debug('WA-JS:message');

export interface FileMessageOptions extends SendMessageOptions {
  type?: string;
  caption?: string;
  footer?: string;
  filename?: string;
  mimetype?: string;
}

export interface AutoDetectMessageOptions extends FileMessageOptions {
  type: 'auto-detect';
}

/**
 * Send an audio message as a PTT, like a recorded message
 *
 * @example
 * ```javascript
 * // PTT audio
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:audio/mp3;base64,<a long base64 file...>',
 *  {
 *    type: 'audio',
 *    isPtt: true // false for common audio
 *  }
 * );
 * ```
 */
export interface AudioMessageOptions extends FileMessageOptions {
  type: 'audio';
  isPtt?: boolean;
  isViewOnce?: boolean;
  /**
   * Send an audio message as a PTT with waveform
   *
   * @example
   * ```javascript
   * // Enable waveform
   * WPP.chat.sendFileMessage(
   *  '[number]@c.us',
   *  'data:audio/mp3;base64,<a long base64 file...>',
   *  {
   *    type: 'audio',
   *    isPtt: true,
   *    waveform: true // false to disable
   *  }
   * );
   * // Disable waveform
   * WPP.chat.sendFileMessage(
   *  '[number]@c.us',
   *  'data:audio/mp3;base64,<a long base64 file...>',
   *  {
   *    type: 'audio',
   *    isPtt: true,
   *    waveform: false
   *  }
   * );
   * ```
   */
  waveform?: boolean;
}

export interface DocumentMessageOptions
  extends FileMessageOptions, MessageButtonsOptions {
  type: 'document';
}

export interface ImageMessageOptions
  extends FileMessageOptions, MessageButtonsOptions {
  type: 'image';
  isViewOnce?: boolean;
  isHD?: boolean;
}

export interface StickerMessageOptions extends FileMessageOptions {
  type: 'sticker';
}

export interface VideoMessageOptions
  extends FileMessageOptions, MessageButtonsOptions {
  type: 'video';
  isGif?: boolean;
  isPtv?: boolean;
  isViewOnce?: boolean;
  isHD?: boolean;
}

/**
 * Send a file message, that can be an audio, document, image, sticker or video
 *
 * @example
 * ```javascript
 * // Single document
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:application/msword;base64,<a long base64 file...>',
 *  {
 *    type: 'document',
 *    caption: 'My document', // Optional
 *    filename: 'myfile.doc', // Optional
 *    mimetype: 'application/msword' // Optional
 *  }
 * );
 *
 * // Image with view once
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:image/jpeg;base64,<a long base64 file...>',
 *  {
 *    type: 'image',
 *    caption: 'My image', // Optional
 *    isViewOnce: true
 *  }
 * );
 *
 * // PTT audio
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:audio/mp3;base64,<a long base64 file...>',
 *  {
 *    type: 'audio',
 *    isPtt: true // false for common audio
 *  }
 * );
 *
 * // Image with view buttons
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:image/jpeg;base64,<a long base64 file...>',
 *  {
 *    type: 'image',
 *    caption: 'My image'
 *    buttons: [
 *      {
 *        id: 'your custom id 1',
 *        text: 'Some text'
 *      },
 *      {
 *        id: 'another id 2',
 *        text: 'Another text'
 *      }
 *    ],
 *    footer: 'Footer text' // Optional
 *  }
 * );
 *
 * // Image as Sticker
 * WPP.chat.sendFileMessage(
 *   '[number]@c.us',
 *   'data:image/png;base64,<a long base64 file...>',
 *   {
 *     type: 'sticker'
 *   }
 * );
 *
 * // A simple video
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:video/mp4;base64,<a long base64 file...>',
 *  {
 *    type: 'video',
 *  }
 * );
 *
 * // A PTV Video (micro video)
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'data:video/mp4;base64,<a long base64 file...>',
 *  {
 *    type: 'video',
 *    isPtv: true,
 *  }
 * );
 *
 * // Media using Link, the link must be public accessible
 * // CORS must be enabled on the server and available for all domains
 * // (Access-Control-Allow-Origin: *)
 * // If the server does not have CORS enabled, you can use a public CORS proxy
 * WPP.chat.sendFileMessage(
 *  '[number]@c.us',
 *  'https://example.com/image.jpg',
 *  {
 *    type: 'image',
 *    caption: 'My image from URL', // Optional
 *  }
 * );
 * ```
 * @category Message
 * @return  {SendMessageReturn} The result
 */
export async function sendFileMessage(
  chatId: string | Wid,
  content: string | Blob | File,
  options:
    | AutoDetectMessageOptions
    | AudioMessageOptions
    | DocumentMessageOptions
    | ImageMessageOptions
    | VideoMessageOptions
    | StickerMessageOptions
): Promise<SendMessageReturn> {
  options = {
    ...defaultSendMessageOptions,
    ...{
      type: 'auto-detect',
      waveform: true,
    },
    ...options,
  };

  let chat: ChatModel;
  if (chatId?.toString() == 'status@broadcast') {
    chat = new ChatModel({
      id: createWid(STATUS_JID),
    });
  } else {
    chat = await assertFindChat(chatId);
  }

  const file = await convertToFile(content, options.mimetype, options.filename);

  const filename = file.name;

  // Determine media type for file size validation
  const mediaType = getMediaTypeForValidation(options.type, file.type);
  const isStatusMedia = chatId?.toString() === 'status@broadcast';

  // Validate file size before processing
  try {
    const isStatusOrigin = isStatusMedia
      ? 'STATUS_TAB_CAMERA_PHOTO_LIBRARY'
      : null;

    const limit = whatsapp.MediaGatingUtils.getUploadLimit(
      mediaType,
      isStatusOrigin
    );

    debug(
      `Validating file size: ${file.size} bytes, limit for ${mediaType}: ${limit} bytes`
    );

    if (file.size > limit) {
      throw new WPPError(
        'file_too_large',
        `File size ${formatFileSize(file.size)} exceeds the upload limit of ${formatFileSize(limit)} for ${mediaType} files`,
        { fileSize: file.size, limit, mediaType }
      );
    }
  } catch (error) {
    // If it's already our WPPError, re-throw it
    if (error instanceof WPPError) {
      throw error;
    }
  }

  const opaqueData = await OpaqueData.createFromData(file, file.type);

  const rawMediaOptions: {
    isPtt?: boolean;
    asDocument?: boolean;
    asGif?: boolean;
    isAudio?: boolean;
    asSticker?: boolean;
    precomputedFields?: {
      duration: number;
      waveform: Uint8Array;
    };
  } = {};

  let isViewOnce: boolean | undefined;
  let maxDimension;

  if (options.type === 'audio') {
    rawMediaOptions.isPtt = options.isPtt;
    if (options.isPtt) {
      isViewOnce = options.isViewOnce;
    }
    rawMediaOptions.precomputedFields = await prepareAudioWaveform(
      options as any,
      file
    );
  } else if (options.type === 'image') {
    isViewOnce = options.isViewOnce;
    maxDimension = options?.isHD ? 2560 : 1600;
  } else if (options.type === 'video') {
    isViewOnce = options.isViewOnce;
    rawMediaOptions.asGif = options.isGif;
  } else if (options.type === 'document') {
    rawMediaOptions.asDocument = true;
  } else if (options.type === 'sticker') {
    rawMediaOptions.asSticker = true;
  }

  const mediaPrep = prepRawMedia(opaqueData, {
    ...rawMediaOptions,
    maxDimension,
  });

  // The generated message in `sendToChat` is merged with `productMsgOptions`
  let rawMessage = await prepareRawMessage<RawMessage>(
    chat,
    {
      caption: options.caption || filename,
      filename: filename,
      footer: options.footer,
      isCaptionByUser: options.caption != undefined,
    },
    options
  );

  if ((options as any).buttons) {
    // The interactive header needs the media kind (document/image/video)
    const kind: string =
      options.type !== 'auto-detect'
        ? options.type
        : file.type.startsWith('image/')
          ? 'image'
          : file.type.startsWith('video/')
            ? 'video'
            : 'document';
    if (!rawMessage.type || rawMessage.type === 'chat') {
      rawMessage.type = kind;
    }
  }

  rawMessage = prepareMessageButtons(rawMessage, options as any);

  if (options.markIsRead) {
    debug(`marking chat is read before send file`);
    // Try to mark is read and ignore errors
    await markIsRead(chat.id).catch(() => null);
  }

  await mediaPrep.waitForPrep();
  const mediaData =
    (mediaPrep as any)._mediaData || (mediaPrep as any).mediaData;
  if ((options as any)?.isPtv) {
    mediaData.type = 'ptv';
    mediaData.fullHeight = 1128;
    mediaData.fullWidth = 1128;
  }
  debug(`sending message (${options.type}) with id ${rawMessage.id}`);

  const processedOptions: any = {
    caption: options.caption,
    footer: options.footer,
    isViewOnce,
    productMsgOptions: chatId === 'status@broadcast' ? undefined : rawMessage,
    addEvenWhilePreparing: false,
    type: rawMessage.type,
    useBasePropsType: rawMessage.type === 'interactive',
    // WhatsApp reads these interactive fields from the options (not only from
    // `productMsgOptions`) and overwrites the message props with them
    ...(rawMessage.type === 'interactive'
      ? {
          nativeFlowInteractiveMsg: rawMessage.nativeFlowInteractiveMsg,
          nativeFlowName: rawMessage.nativeFlowName,
          interactiveHeader: rawMessage.interactiveHeader,
          interactiveType: rawMessage.interactiveType,
          interactivePayload: rawMessage.interactivePayload,
        }
      : {}),
  };

  let sendMsgResult;

  if (mediaPrep.sendToChat.length === 1) {
    sendMsgResult = mediaPrep.sendToChat({ chat, options: processedOptions });
  } else {
    sendMsgResult = mediaPrep.sendToChat(chat, processedOptions);
  }

  // Wait for message register
  let message: any = null;

  if (rawMessage.to?.toString() == 'status@broadcast') {
    message = await waitForOwnStatusMsg(rawMessage);
  } else {
    message = await new Promise<MsgModel>((resolve) => {
      chat.msgs.on('add', function fn(msg: MsgModel) {
        if (msg.id === rawMessage.id) {
          chat.msgs.off('add', fn);
          resolve(msg);
        }
      });
    });
  }

  debug(`message file ${message.id} queued`);

  function uploadStage(mediaData: any, stage: string) {
    debug(`message file ${message.id} is ${stage}`);
  }
  message.on('change:mediaData.mediaStage', uploadStage);

  sendMsgResult.finally(() => {
    message.off('change:mediaData.mediaStage', uploadStage);
  });

  if (chatId !== 'status@broadcast') {
    let sendResult: whatsapp.SendMsgResultObject | null = null;

    if (options.waitForAck) {
      debug(`waiting ack for ${message.id}`);

      sendResult = await sendMsgResult;

      debug(
        `ack received for ${message.id} (ACK: ${message.ack}, SendResult: ${JSON.stringify(sendResult)})`
      );
    }

    return {
      id: message.id?.toString(),
      ack: message.ack!,
      sendMsgResult: sendResult,
    };
  } else {
    // Forced a mode to return the ID since sendMediaResult was giving an error when sending with certain parameters.
    const msg = await new Promise<MsgModel>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(
          new WPPError(
            'timeout_on_send_status',
            'Timeout for wait response of send media status'
          )
        );
      }, 30000);

      const interval = setInterval(async () => {
        const get = await getMessageById(message.id);
        if (get.ack! > 0) {
          clearInterval(interval);
          clearTimeout(timeout);
          resolve(get);
        }
      }, 1500);
    });
    return {
      id: msg.id?.toString(),
      ack: msg.ack!,
      sendMsgResult: {
        messageSendResult: SendMsgResult.OK,
      },
    };
  }
}

/**
 * Wait for WhatsApp to register our own status message.
 *
 * `StatusV3Store` keys the statuses by the author chat and, after the LID
 * migration, that id is not necessarily the addressing mode of the outgoing
 * `from`: `status@broadcast` is not a LID chat, so `prepareRawMessage` uses the
 * phone number while the store can hold the LID (or the other way around).
 * Comparing only the literal ids never matches then, and without a deadline the
 * send stays pending forever instead of failing.
 */
function waitForOwnStatusMsg(rawMessage: RawMessage): Promise<MsgModel> {
  const ownIds = new Set<string>();
  const from = rawMessage.from;

  if (from) {
    ownIds.add(from.toString());

    const equivalentId = from.isLid()
      ? lidPnCache?.getPhoneNumber?.(from)
      : lidPnCache?.getCurrentLid?.(from);

    if (equivalentId) {
      ownIds.add(equivalentId.toString());
    }
  }

  return new Promise<MsgModel>((resolve, reject) => {
    const timeout = setTimeout(() => {
      StatusV3Store.off('change:lastReceivedKey', fn);
      reject(
        new WPPError(
          'timeout_on_register_status',
          'Timeout waiting for WhatsApp to register the status message',
          { from: from?.toString() }
        )
      );
    }, 30000);

    async function fn(chat: ChatModel, msgKey: MsgKey) {
      if (!ownIds.has(chat.id.toString())) {
        return;
      }

      StatusV3Store.off('change:lastReceivedKey', fn);
      clearTimeout(timeout);
      resolve(await getMessageById(msgKey));
    }

    StatusV3Store.on('change:lastReceivedKey', fn);
  });
}

/**
 * Generate a white thumbnail as WhatsApp generate for video files
 */
function generateWhiteThumb(width: number, height: number, maxSize: number) {
  let r = height ?? maxSize;
  let i = width ?? maxSize;

  if (r > i) {
    if (r > maxSize) {
      i *= maxSize / r;
      r = maxSize;
    }
  } else {
    if (i > maxSize) {
      r *= maxSize / i;
      i = maxSize;
    }
  }

  const bounds = { width: Math.max(r, 1), height: Math.max(i, 1) };

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;

  canvas.width = bounds.width;
  canvas.height = bounds.height;

  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  return {
    url: canvas.toDataURL('image/jpeg'),
    width: bounds.width,
    height: bounds.height,
    fullWidth: width,
    fullHeight: height,
  };
}

loader.onFullReady(() => {
  wrapModuleFunction(generateVideoThumbsAndDuration, async (func, ...args) => {
    const [data] = args;

    try {
      return await func(...args);
    } catch (error: any) {
      if (
        typeof error.message === 'string' &&
        error.message.includes('MEDIA_ERR_SRC_NOT_SUPPORTED')
      ) {
        try {
          const arrayBuffer = await data.file.arrayBuffer();
          const info = getVideoInfoFromBuffer(arrayBuffer);

          return {
            duration: info.duration,
            thumbs: data.maxDimensions.map((d) =>
              generateWhiteThumb(info.width, info.height, d)
            ),
          };
        } catch (error) {
          console.error(error);
        }
      }

      throw error;
    }
  });

  wrapModuleFunction(processRawSticker, async (func, ...args) => {
    const [data] = args;
    const result = await func(...args);

    if (data.type() === 'image/webp') {
      const blob = data.forceToBlob();
      const buffer = await blobToArrayBuffer(blob);

      if (isAnimatedWebp(buffer)) {
        result.mediaBlob = await OpaqueData.createFromData(blob, data.type());
      }
    }

    return result;
  });

  wrapModuleFunction(uploadMedia, async (func, ...args) => {
    const [data] = args;
    if ((data as any).mediaType == 'ptv') {
      (data as any).mediaType = 'video';
      return await func(data);
    } else {
      return await func(...args);
    }
  });
});

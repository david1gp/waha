/*!
 * Copyright 2021 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { internalEv } from '../../eventEmitter';
import * as loader from '../../loader';
import { ChatModel, ChatStore } from '../../whatsapp';

loader.onInjected(() => register());
let emitTimeout: any = null;

function register() {
  ChatStore.on('change:active', (chat: ChatModel) => {
    if (emitTimeout) {
      clearTimeout(emitTimeout);
    }

    emitTimeout = setTimeout(() => {
      internalEv.emit('chat.active_chat', chat.active ? chat : null);
    }, 50);
  });
}

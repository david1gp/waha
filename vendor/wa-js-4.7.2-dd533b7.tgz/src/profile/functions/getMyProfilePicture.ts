/*!
 * Copyright 2024 WPPConnect Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { getMyUserWid } from '../../conn/functions/getMyUserWid';
import { ProfilePicThumbModel, ProfilePicThumbStore } from '../../whatsapp';

/**
 * Get your current profile picture
 *
 * @example
 * ```javascript
 * await WPP.profile.getMyProfilePicture();
 * ```
 *
 * @category Profile
 */

export async function getMyProfilePicture(): Promise<ProfilePicThumbModel> {
  const user = getMyUserWid();
  const pic = await ProfilePicThumbStore.find(user);
  return pic;
}

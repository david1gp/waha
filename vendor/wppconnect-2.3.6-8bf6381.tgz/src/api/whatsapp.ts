/*
 * This file is part of WPPConnect.
 *
 * WPPConnect is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WPPConnect is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with WPPConnect.  If not, see <https://www.gnu.org/licenses/>.
 */

import axios from 'axios';
import * as fs from 'fs';
import { Page } from 'puppeteer';
import { pipeline } from 'stream/promises';
import { closeBrowser } from '../controllers/browser';
import { CreateConfig } from '../config/create-config';
import { useragentOverride } from '../config/WAuserAgente';
import { sleep } from '../utils/sleep';
import { evaluateAndReturn } from './helpers';
import { magix, makeOptions, newMagix, timeout } from './helpers/decrypt';
import { BusinessLayer } from './layers/business.layer';
import { GetMessagesParam, Message } from './model';

/** Per-request timeout so a single fetch cannot hang a send indefinitely. */
export const DECRYPT_TIMEOUT_MS = 30000;

/**
 * GETs a URL until HTTP 200, retrying transient failures (including a rejected
 * status) with linear backoff. Replaces an unbounded `while` loop that wedged
 * `decryptFile` forever on a persistently failing download. Each attempt is
 * bounded by `timeout` (defaults to {@link DECRYPT_TIMEOUT_MS}) so a stalled
 * response cannot hang either.
 */
export async function getUntilOk(
  url: string,
  options?: any,
  maxAttempts = 3
): Promise<any> {
  const requestOptions = { timeout: DECRYPT_TIMEOUT_MS, ...options };
  let lastError: any;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await axios.get<any>(url, requestOptions);
      if (res.status == 200) {
        return res;
      }
      lastError = new Error(`unexpected status ${res.status}`);
    } catch (error) {
      lastError = error;
    }

    if (attempt < maxAttempts) {
      await timeout(2000 * attempt);
    }
  }

  throw new Error(
    `Error trying to download the file (${
      (lastError && lastError.message) || lastError
    }).`
  );
}

export class Whatsapp extends BusinessLayer {
  /**
   * The page binding exposed by `wireConnectionEvents` can only be registered
   * once per page, but a page may be reused by a later client. This maps each
   * page to the callback of the client that most recently wired it, so the
   * existing binding can be redirected to the current client.
   */
  private static readonly connectionDispatchers = new WeakMap<
    Page,
    (isRegistered: boolean) => void
  >();

  private connected: boolean | null = null;

  constructor(public page: Page, session?: string, options?: CreateConfig) {
    super(page, session, options);
  }

  protected async afterPageScriptInjected() {
    await super.afterPageScriptInjected();
    await this.wireConnectionEvents();

    this.page
      .evaluate(() => WPP.conn.isRegistered())
      .then((isAuthenticated) => {
        // Do not overwrite a connection event that arrived while the initial
        // state was being read.
        if (this.connected === null) {
          this.connected = isAuthenticated;
        }
      })
      .catch(() => null);
  }

  /**
   * Forwards wa-js connection events to the Node side instead of polling
   * `WPP.conn.isRegistered()` every second. Re-registered after every page
   * load, since the in-page listeners do not survive navigation.
   */
  protected async wireConnectionEvents() {
    const page = this.page;

    // `exposeFunction` can only bind a given name once and a page can be
    // reused by a later client, so route the page binding through a per-page
    // dispatcher. A second client re-points the existing binding at itself
    // instead of leaving the previous client's callback installed.
    await page
      .exposeFunction('onConnectionChange', (isRegistered: boolean) => {
        Whatsapp.connectionDispatchers.get(page)?.(isRegistered);
      })
      .catch(() => null);

    Whatsapp.connectionDispatchers.set(page, (isRegistered: boolean) =>
      this.onConnectionChange(isRegistered)
    );

    await evaluateAndReturn(page, () => {
      const handler = (window as any).onConnectionChange;
      if (typeof handler !== 'function' || handler.__wppWired) {
        return;
      }
      handler.__wppWired = true;
      WPP.on('conn.authenticated', () => handler(true));
      WPP.on('conn.main_ready', () => handler(true));
      WPP.on('conn.logout', () => handler(false));
      WPP.on('conn.require_auth', () => handler(false));
    }).catch(() => null);
  }

  protected onConnectionChange(isRegistered: boolean) {
    if (isRegistered === this.connected) {
      return;
    }

    const wasConnected = this.connected;
    this.connected = isRegistered;

    // Only a registered -> unregistered transition is a disconnection. The
    // first event on a fresh page can arrive before afterPageScriptInjected()
    // records the initial state, and a page that was never paired is not a
    // phone that disconnected.
    if (!isRegistered && wasConnected === true) {
      this.log('info', 'Session Unpaired', { type: 'session' });
      setTimeout(() => {
        if (this.statusFind) {
          try {
            this.statusFind('disconnectedMobile', this.session || '');
          } catch (error) {}
        }
      }, 1000);
    }
  }
  /**
   * Decrypts message file
   * @param data Message object
   * @returns Decrypted file buffer (null otherwise)
   */
  public async downloadFile(data: string) {
    return await evaluateAndReturn(
      this.page,
      (data) => WAPI.downloadFile(data),
      data
    );
  }

  /**
   * Download and returns the media content in base64 format
   * @param messageId Message or id
   * @returns Base64 of media
   */
  public async downloadMedia(messageId: string | Message): Promise<string> {
    if (typeof messageId !== 'string') {
      messageId = messageId.id;
    }

    if (!messageId) {
      throw new Error(
        'downloadMedia: messageId is undefined or null. ' +
          'Make sure the message object (e.g. quotedMsgObj) exists before calling downloadMedia.'
      );
    }

    return await evaluateAndReturn(
      this.page,
      async (messageId) => {
        const media = await WPP.chat.downloadMedia(messageId);
        if (!media) {
          throw new Error(
            `downloadMedia: no media found for message id "${messageId}". The message may not contain downloadable media.`
          );
        }
        return WPP.util.blobToBase64(media);
      },
      messageId
    );
  }

  /**
   * Get the puppeteer page instance
   * @returns The Whatsapp page
   */
  get waPage(): Page {
    return this.page;
  }

  /**
   * Get the puppeteer page screenshot
   * @returns The Whatsapp page screenshot as a PNG encoded in base64 (not the full data URI, just the base64 section)
   */
  public async takeScreenshot() {
    if (this.page) {
      return await this.page.screenshot({ encoding: 'base64' });
    }
  }

  /**
   * Clicks on 'use here' button (When it gets unlaunched)
   * This method tracks the class of the button
   * WhatsApp Web might change this class name over time
   * Don't rely on this method
   */
  public async useHere() {
    return await evaluateAndReturn(this.page, () => WAPI.takeOver());
  }

  /**
   * Log out of WhatsApp
   * @returns boolean
   */
  public async logout() {
    return await evaluateAndReturn(this.page, () => WPP.conn.logout());
  }

  /**
   * Closes page and browser
   * @internal
   */
  public async close() {
    this.cancelQrLoop();

    // The page may already be closed (autoClose, crash or logout), but the
    // browser and its OS process tree must still be released
    await this.page.close().catch(() => null);
    await closeBrowser(this.page.browser());

    return true;
  }

  /**
   * Return PID process
   * @internal
   */
  public getPID() {
    const browser = this.page.browser();
    const process = browser.process();
    return process?.pid;
  }

  /**
   * Get a message by its ID
   * @param messageId string
   * @returns Message object
   */
  public async getMessageById(messageId: string) {
    return (await evaluateAndReturn(
      this.page,
      (messageId: any) => WAPI.getMessageById(messageId),
      messageId
    )) as Message;
  }

  /**
   * Returns a list of messages from a chat
   * @param chatId string ID of the conversation or group
   * @param params GetMessagesParam Result filtering options (count, id, direction) see {@link GetMessagesParam}.
   * @returns Message object
   */
  public async getMessages(chatId: string, params: GetMessagesParam = {}) {
    return await evaluateAndReturn(
      this.page,
      ({ chatId, params }) => WAPI.getMessages(chatId, params),
      { chatId, params: params as any }
    );
  }

  /**
   * Decrypts message file
   * @param message Message object
   * @returns Decrypted file buffer (`null` otherwise)
   */
  public async decryptFile(message: Message) {
    const mediaUrl = message.clientUrl || message.deprecatedMms3Url;

    const options = makeOptions(useragentOverride);

    if (!mediaUrl)
      throw new Error(
        'message is missing critical data (`mediaUrl`) needed to download the file.'
      );
    let res: any;
    try {
      res = await getUntilOk(mediaUrl.trim(), options);
    } catch (error) {
      throw new Error('Error trying to download the file.');
    }
    const buff = Buffer.from(res.data, 'binary');
    return magix(buff, message.mediaKey, message.type, message.size);
  }

  public async decryptAndSaveFile(
    message: Message,
    savePath: string
  ): Promise<void> {
    const mediaUrl = message.clientUrl || message.deprecatedMms3Url;

    if (!mediaUrl) {
      throw new Error(
        'Message is missing critical data needed to download the file.'
      );
    }

    try {
      const tempSavePath: string = savePath + '.encrypted';
      await this.downloadEncryptedFile(mediaUrl.trim(), tempSavePath);

      const inputReadStream = fs.createReadStream(tempSavePath);
      const outputWriteStream = fs.createWriteStream(savePath);
      const decryptedStream = newMagix(
        message.mediaKey,
        message.type,
        message.size
      );

      await pipeline(inputReadStream, decryptedStream, outputWriteStream);

      console.log(
        `Deciphering complete. Deleting the encrypted file: ${tempSavePath}`
      );
      await fs.promises.unlink(tempSavePath);
      console.log('Encrypted file deleted successfully');
    } catch (error) {
      throw error;
    }
  }

  downloadEncryptedFile = async (
    url: string,
    outputPath: string,
    retries: number = 3
  ) => {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const response = await axios.get(
          url,
          makeOptions(useragentOverride, 'stream')
        );

        const writer = fs.createWriteStream(outputPath);
        await pipeline(response.data, writer);

        console.log(`Encrypted file downloaded at ${outputPath}`);
        return;
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        console.error(`Attempt ${attempt} failed: `, errorMessage);
        if (attempt === retries) {
          console.error(
            `${outputPath} - All attempt failed to download the file: ${url}`
          );
          throw error;
        }

        console.log(
          `${outputPath} - Retrying to download the file: ${url} in 5 seconds...`
        );
        await sleep(5000);
      }
    }
  };

  /**
   * Rejects a call received via WhatsApp
   * @param callId string Call ID, if not passed, all calls will be rejected
   * @returns Number of rejected calls
   */
  public async rejectCall(callId?: string) {
    return await evaluateAndReturn(
      this.page,
      ({ callId }) => WPP.call.rejectCall(callId),
      {
        callId,
      }
    );
  }
}

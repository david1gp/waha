/*
 * This file is part of WPPConnect.
 *
 * WPPConnect is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WPPConnect is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with WPPConnect.  If not, see <https://www.gnu.org/licenses/>.
 */

import { Page } from 'puppeteer';
import { Logger } from 'winston';
import { CreateConfig, defaultOptions } from '../../config/create-config';
import {
  asciiQr,
  isAuthenticated,
  isInsideChat,
  needsToScan,
} from '../../controllers/auth';
import {
  initWhatsapp,
  injectApi,
  InjectionTimeoutError,
} from '../../controllers/browser';
import { defaultLogger, LogLevel } from '../../utils/logger';
import { sleep } from '../../utils/sleep';
import { evaluateAndReturn, scrapeImg } from '../helpers';
import {
  CatchQRCallback,
  HostDevice,
  LinkByCodeCallback,
  LoadingScreenCallback,
  StatusFindCallback,
} from '../model';
import { SocketState } from '../model/enum';
import { ScrapQrcode } from '../model/qrcode';

export class HostLayer {
  readonly session: string;
  readonly options: CreateConfig;
  readonly logger: Logger;

  protected autoCloseInterval = null;
  protected autoCloseCalled = false;

  protected isInitialized = false;
  protected isInjected = false;
  protected pageLoadPromise?: Promise<void>;
  protected pageLoadAbort?: AbortController;
  protected injectionStartedAt?: number;
  protected documentWatch?: Promise<void>;
  protected isNavigating = false;
  protected isStarted = false;
  protected qrLoopCancelled = false;
  protected isLogged = false;
  protected isInChat = false;
  protected urlCode = '';
  protected attempt = 0;

  public catchQR?: CatchQRCallback = null;
  public statusFind?: StatusFindCallback = null;
  public onLoadingScreen?: LoadingScreenCallback = null;
  public catchLinkCode?: LinkByCodeCallback = null;

  constructor(public page: Page, session?: string, options?: CreateConfig) {
    this.session = session;
    this.options = { ...defaultOptions, ...options };

    this.logger = this.options.logger || defaultLogger;

    this.log('info', 'Initializing...');
    this.initialize();
  }

  protected log(level: LogLevel, message: string, meta: object = {}) {
    this.logger.log({
      level,
      message,
      session: this.session,
      type: 'client',
      ...meta,
    });
  }

  protected async initialize() {
    this.page.on('close', () => {
      this.cancelAutoClose();
      this.log('verbose', 'Page Closed', { type: 'page' });
    });

    this.page.on('load', () => {
      this.log('verbose', 'Page loaded', { type: 'page' });
      this.isInjected = false;

      // One budget per injection cycle, so a reload loop cannot extend it
      this.injectionStartedAt ??= Date.now();

      // Also aborted on document change; this covers pages without a CDP session
      this.pageLoadAbort?.abort();
      const abort = new AbortController();
      this.pageLoadAbort = abort;

      const previousPageLoad = this.pageLoadPromise?.catch(() => undefined);
      const pageLoad = (previousPageLoad || Promise.resolve()).then(() =>
        this.afterPageLoad(abort.signal)
      );

      this.pageLoadPromise = pageLoad;
      void pageLoad.catch(() => undefined);
    });

    this.documentWatch = this.watchDocumentChanges();
    this.isInitialized = true;
  }

  protected async watchDocumentChanges() {
    try {
      // Page 'framenavigated' also fires on pushState; these CDP events only for a new document
      const session = await this.page.createCDPSession();
      await session.send('Page.enable');
      const { frameTree } = await session.send('Page.getFrameTree');
      let mainFrameId = frameTree.frame.id;

      // Steps in flight fail from here on, before the new document exists
      session.on('Page.frameStartedNavigating', (event) => {
        if (
          event.frameId === mainFrameId &&
          !/samedocument/i.test(event.navigationType)
        ) {
          this.isNavigating = true;
        }
      });
      session.on('Page.frameNavigated', ({ frame }) => {
        if (frame.parentId) return;
        mainFrameId = frame.id;
        this.isNavigating = false;
        this.isInjected = false;
        this.pageLoadAbort?.abort();
      });
    } catch (error) {
      this.log('warn', 'Could not watch document changes', { error });
    }
  }

  /**
   * Exposes a Node callback on the page. A page reused across clients
   * (`browserWS` or an injected `page`) still carries the binding from the
   * previous client, and puppeteer refuses to overwrite it (`... already
   * exists!`). Drop the stale binding first so the newest client's callback
   * wins; any other error propagates unchanged.
   */
  protected async exposePageFunction(
    name: string,
    fn: (...args: any[]) => any
  ): Promise<void> {
    try {
      await this.page.exposeFunction(name, fn);
    } catch (error) {
      if (!/already exists/i.test((error as Error)?.message ?? '')) {
        throw error;
      }

      await this.page.removeExposedFunction(name).catch(() => null);
      await this.page.exposeFunction(name, fn);
    }
  }

  protected async afterPageLoad(signal?: AbortSignal) {
    if (signal?.aborted) {
      return;
    }

    this.log('verbose', 'Injecting wapi.js');

    try {
      await injectApi(this.page, this.onLoadingScreen, {
        timeout: this.options.injectionTimeout,
        startedAt: this.injectionStartedAt,
        signal,
        config: {
          deviceName: this.options.deviceName,
          disableGoogleAnalytics: this.options.disableGoogleAnalytics,
          googleAnalyticsId: this.options.googleAnalyticsId,
          linkPreviewApiServers: this.options.linkPreviewApiServers,
          poweredBy: this.options.poweredBy,
        },
      });
    } catch (error) {
      if (this.isNavigating) {
        await this.waitForNavigationCommit(signal);
      }
      // A newer document owns the page now; its injection decides the outcome
      if (signal?.aborted) {
        this.log('verbose', 'wapi.js injection superseded by page reload');
        return;
      }

      const failure =
        this.isInjectionExpired() && !(error instanceof InjectionTimeoutError)
          ? new InjectionTimeoutError(this.options.injectionTimeout, {
              cause: error,
            })
          : error;

      this.injectionStartedAt = undefined;
      this.log('verbose', 'wapi.js failed');
      this.log('error', failure);
      throw failure;
    }

    if (signal?.aborted) {
      return;
    }

    this.injectionStartedAt = undefined;
    this.isInjected = true;
    this.log('verbose', 'wapi.js injected');
    this.afterPageScriptInjected().catch((error) => this.log('error', error));
  }

  protected async waitForNavigationCommit(signal?: AbortSignal) {
    while (
      this.isNavigating &&
      !signal?.aborted &&
      !this.page.isClosed() &&
      !this.isInjectionExpired()
    ) {
      await sleep(50);
    }
  }

  protected isInjectionExpired() {
    const timeout = this.options.injectionTimeout;
    return (
      timeout > 0 &&
      this.injectionStartedAt !== undefined &&
      Date.now() >= this.injectionStartedAt + timeout
    );
  }

  protected async afterPageScriptInjected() {
    this.getWAVersion()
      .then((version) => {
        this.log('info', `WhatsApp WEB version: ${version}`);
      })
      .catch(() => null);
    this.getWAJSVersion()
      .then((version) => {
        this.log('info', `WA-JS version: ${version}`);
      })
      .catch(() => null);

    evaluateAndReturn(this.page, () => {
      WPP.on('conn.main_ready', (window as any).checkInChat);
    }).catch(() => null);

    if (typeof this.options.phoneNumber === 'string') {
      await evaluateAndReturn(this.page, () => {
        WPP.on('conn.link_code_change', (window as any).onLinkCode);
        WPP.on('conn.link_code_expired', (window as any).onLinkCodeExpired);
        WPP.on('conn.link_code_error', (error) =>
          (window as any).onLinkCodeError(error.message)
        );
      }).catch(() => null);
      await this.loginByCode(this.options.phoneNumber).catch((error) =>
        this.log('error', error)
      );
    } else {
      await evaluateAndReturn(this.page, () => {
        WPP.on('conn.auth_code_change', (window as any).checkQrCode);
      }).catch(() => null);
      this.checkQrCode().catch((error) => this.log('error', error));
    }
    this.checkInChat().catch((error) => this.log('error', error));
  }

  public async start() {
    if (this.isStarted) {
      return;
    }

    this.isStarted = true;

    await this.documentWatch;
    await initWhatsapp(
      this.page,
      null,
      false,
      this.options.whatsappVersion,
      this.options.proxy,
      this.log.bind(this)
    );

    await this.exposePageFunction('checkQrCode', () => this.checkQrCode());
    await this.exposePageFunction('onLinkCode', (code: string) =>
      this.onLinkCode(code)
    );
    await this.exposePageFunction('onLinkCodeExpired', () =>
      this.log('warn', 'Login by code expired; call refreshLinkCode() to retry')
    );
    await this.exposePageFunction('onLinkCodeError', (message: string) =>
      this.log('error', `Login by code failed: ${message}`)
    );
    await this.exposePageFunction('checkInChat', () => this.checkInChat());

    this.page.on('close', () => {
      this.cancelQrLoop();
    });
  }

  protected async checkQrCode() {
    if (this.qrLoopCancelled || this.page.isClosed()) return;
    const needScan = await needsToScan(this.page).catch(() => null);
    if (this.qrLoopCancelled || this.page.isClosed()) return;

    // A navigation can invalidate the execution context while waiting for QR.
    // An unknown result is not proof that the session has registered.
    if (needScan === null) return;
    this.isLogged = !needScan;
    if (!needScan) {
      this.attempt = 0;
      return;
    }

    const result = await this.getQrCode();
    if (this.qrLoopCancelled || this.page.isClosed()) return;

    if (!result?.urlCode || this.urlCode === result.urlCode) {
      return;
    }
    this.urlCode = result.urlCode;
    this.attempt++;

    let qr = '';

    if (this.options.logQR || this.catchQR) {
      qr = await asciiQr(this.urlCode);
    }
    if (this.qrLoopCancelled || this.page.isClosed()) return;

    if (this.options.logQR) {
      this.log(
        'info',
        `Waiting for QRCode Scan (Attempt ${this.attempt})...:\n${qr}`,
        { code: this.urlCode }
      );
    } else {
      this.log('verbose', `Waiting for QRCode Scan: Attempt ${this.attempt}`);
    }

    this.catchQR?.(result.base64Image, qr, this.attempt, result.urlCode);
  }

  /**
   * Stop QR attempts and suppress pending QR callbacks for this client.
   * Create a new client to start pairing again.
   * @category Host
   */
  public cancelQrLoop(): void {
    this.qrLoopCancelled = true;
  }

  protected async loginByCode(phone: string) {
    await evaluateAndReturn(
      this.page,
      async ({ phone }) => {
        await WPP.conn.startLinkDeviceCodeForPhoneNumber(phone);
      },
      { phone }
    );
  }

  protected onLinkCode(code: string) {
    if (this.options.logQR) {
      this.log('info', `Waiting for Login By Code (Code: ${code})\n`);
    } else {
      this.log('verbose', `Waiting for Login By Code`);
    }
    this.catchLinkCode?.(code);
  }

  /**
   * Refreshes the code for the active phone-number linking flow.
   * @category Host
   */
  public async refreshLinkCode(): Promise<string> {
    return await evaluateAndReturn(this.page, () =>
      WPP.conn.refreshLinkDeviceCode()
    );
  }

  protected async checkInChat() {
    const inChat = await isInsideChat(this.page).catch(() => null);
    const wasInChat = this.isInChat;
    this.isInChat = !!inChat;

    if (!inChat || wasInChat) {
      return;
    }
    this.log('http', 'Connected');
    try {
      this.statusFind?.('inChat', this.session);
    } catch (error) {
      this.log('error', error);
    }
  }

  protected tryAutoClose() {
    if (this.autoCloseInterval) {
      this.cancelAutoClose();
    }

    if (
      (this.options.autoClose > 0 || this.options.deviceSyncTimeout > 0) &&
      !this.autoCloseInterval &&
      !this.page.isClosed()
    ) {
      this.log('info', 'Closing the page');
      this.autoCloseCalled = true;
      this.statusFind && this.statusFind('autocloseCalled', this.session);
      try {
        this.page.close();
      } catch (error) {}
    }
  }

  protected startAutoClose(time: number | null = null) {
    if (time === null || time === undefined) {
      time = this.options.autoClose;
    }

    if (time > 0 && !this.autoCloseInterval) {
      const seconds = Math.round(time / 1000);
      this.log('info', `Auto close configured to ${seconds}s`);

      let remain = seconds;
      this.autoCloseInterval = setInterval(() => {
        if (this.page.isClosed()) {
          this.cancelAutoClose();
          return;
        }
        remain -= 1;
        if (remain % 10 === 0 || remain <= 5) {
          this.log('http', `Auto close remain: ${remain}s`);
        }
        if (remain <= 0) {
          this.tryAutoClose();
        }
      }, 1000);
    }
  }

  protected cancelAutoClose() {
    clearInterval(this.autoCloseInterval);
    this.autoCloseInterval = null;
  }

  public async getQrCode() {
    let qrResult: ScrapQrcode | undefined;

    qrResult = await scrapeImg(this.page).catch(() => undefined);

    return qrResult;
  }

  public async waitForQrCodeScan() {
    if (!this.isStarted) {
      throw new Error('waitForQrCodeScan error: Session not started');
    }
    while (!this.page.isClosed() && !this.isLogged) {
      await sleep(200);
      const needScan = await needsToScan(this.page).catch(() => null);
      if (needScan === null) continue;
      this.isLogged = !needScan;
    }
  }

  public async waitForInChat() {
    if (!this.isStarted) {
      throw new Error('waitForInChat error: Session not started');
    }

    if (!this.isLogged) {
      return false;
    }

    const start = Date.now();

    while (!this.page.isClosed() && this.isLogged && !this.isInChat) {
      if (
        this.options.deviceSyncTimeout > 0 &&
        Date.now() - start >= this.options.deviceSyncTimeout
      ) {
        return false;
      }

      await sleep(1000);
      // main_ready may already have fired on the QR screen, so pairing can
      // finish without another event. Publish only the verified transition.
      await this.checkInChat();
    }
    return this.isInChat;
  }

  public async waitForPageLoad() {
    while (!this.page.isClosed()) {
      const pageLoad = this.pageLoadPromise;

      if (!pageLoad) {
        await sleep(50);
        continue;
      }

      const failure = await pageLoad.then(
        () => null,
        (error) => ({ error })
      );

      // Superseded by a newer load: wait for that injection instead
      if (pageLoad !== this.pageLoadPromise) {
        continue;
      }
      if (failure) {
        throw failure.error;
      }
      if (this.isInjected) {
        return;
      }
      // Superseded by a navigation whose 'load' has not fired yet
      if (this.isInjectionExpired()) {
        throw new InjectionTimeoutError(this.options.injectionTimeout);
      }
      await sleep(50);
    }

    throw new Error('Page closed before WAPI injection completed');
  }

  public async waitForLogin() {
    this.log('http', 'Waiting page load');

    await this.waitForPageLoad();

    this.log('http', 'Checking is logged...');
    let authenticated = await isAuthenticated(this.page).catch(() => null);

    this.startAutoClose();

    if (authenticated === false) {
      this.log(
        'http',
        typeof this.options.phoneNumber === 'string'
          ? 'Waiting for Login by Code...'
          : 'Waiting for QRCode Scan...'
      );
      this.statusFind?.('notLogged', this.session);
      await this.waitForQrCodeScan();

      this.log(
        'http',
        typeof this.options.phoneNumber === 'string'
          ? 'Checking Login by Code status...'
          : 'Checking QRCode status...'
      );
      // Wait for interface update
      await sleep(200);
      authenticated = await isAuthenticated(this.page).catch(() => null);

      if (authenticated === null) {
        this.log('warn', 'Failed to authenticate');
        this.statusFind?.('qrReadError', this.session);
      } else if (authenticated) {
        this.log('http', 'Login with success');
        this.statusFind?.('qrReadSuccess', this.session);
      } else {
        this.log('warn', 'Login Fail');
        this.statusFind?.('qrReadFail', this.session);
        this.tryAutoClose();
        throw new Error('Failed to read the QRCode');
      }
    } else if (authenticated === true) {
      this.log('http', 'Authenticated');
      this.statusFind?.('isLogged', this.session);
    }

    if (authenticated === true) {
      // A stored session takes the "Authenticated" branch above without going
      // through waitForQrCodeScan(), so nothing else may have recorded the
      // login yet. waitForInChat() bails out early when isLogged is false.
      this.isLogged = true;
      // Reinicia o contador do autoclose
      this.cancelAutoClose();
      // Wait for interface update
      await sleep(200);
      this.startAutoClose(this.options.deviceSyncTimeout);
      this.log('http', 'Checking phone is connected...');
      const inChat = await this.waitForInChat();

      if (!inChat) {
        this.log('warn', 'Phone not connected');
        this.statusFind?.('phoneNotConnected', this.session);
        this.tryAutoClose();
        throw new Error('Phone not connected');
      }
      await this.waitForPageLoad();
      this.cancelAutoClose();
      return true;
    }

    this.tryAutoClose();

    if (this.autoCloseCalled) {
      this.log('error', 'Auto Close Called');
      throw new Error('Auto Close Called');
    }

    if (this.page.isClosed()) {
      this.log('error', 'Page Closed');
      throw new Error('Page Closed');
    }

    this.log('error', 'Unknow error');
    throw new Error('Unknow error');
  }

  /**
   * @category Host
   * @returns Current host device details
   */
  public async getHostDevice(): Promise<HostDevice> {
    return await evaluateAndReturn(this.page, () => WAPI.getHost());
  }

  /**
   * @category Host
   * @returns Current wid connected
   */
  public async getWid(): Promise<string> {
    return await evaluateAndReturn(this.page, () => WAPI.getWid());
  }

  /**
   * Retrieves WA version
   * @category Host
   */
  public async getWAVersion() {
    await this.page
      .waitForFunction(() => WAPI.getWAVersion())
      .catch(() => null);

    return await evaluateAndReturn(this.page, () => WAPI.getWAVersion());
  }

  /**
   * Retrieves WA-JS version
   * @category Host
   */
  public async getWAJSVersion() {
    await this.page.waitForFunction(() => WPP.version).catch(() => null);

    return await evaluateAndReturn(this.page, () => WPP.version);
  }

  /**
   * Retrieves the connection state
   * @category Host
   */
  public async getConnectionState(): Promise<SocketState> {
    return await evaluateAndReturn(this.page, () => {
      return WPP.whatsapp.Socket.state as SocketState;
    });
  }

  /**
   * Retrieves if the phone is online. Please note that this may not be real time.
   * @category Host
   */
  public async isConnected() {
    await this.waitForPageLoad();
    return await evaluateAndReturn(this.page, () => WAPI.isConnected());
  }

  /**
   * Check is online
   * @category Host
   */
  public async isOnline(): Promise<boolean> {
    return await evaluateAndReturn(this.page, () => WPP.conn.isOnline());
  }

  /**
   * Retrieves if the phone is online. Please note that this may not be real time.
   * @category Host
   */
  public async isLoggedIn() {
    return await evaluateAndReturn(this.page, () => WAPI.isLoggedIn());
  }

  /**
   * Retrieves Battery Level
   * @category Host
   */
  public async getBatteryLevel() {
    return await evaluateAndReturn(this.page, () => WAPI.getBatteryLevel());
  }

  /**
   * Start phone Watchdog, forcing the phone connection verification.
   *
   * @category Host
   * @param interval interval number in miliseconds
   */
  public async startPhoneWatchdog(interval: number = 15000) {
    return await evaluateAndReturn(
      this.page,
      (interval) => WAPI.startPhoneWatchdog(interval),
      interval
    );
  }

  /**
   * Stop phone Watchdog, more details in {@link startPhoneWatchdog}
   * @category Host
   */
  public async stopPhoneWatchdog(interval: number) {
    return await evaluateAndReturn(this.page, () => WAPI.stopPhoneWatchdog());
  }

  /**
   * Check the current session is an MultiDevice session
   * @category Host
   */
  public async isMultiDevice() {
    return await evaluateAndReturn(this.page, () => WPP.conn.isMultiDevice());
  }
  /**
   * Retrieve main interface is authenticated, loaded and synced
   * @category Host
   */
  public async isMainReady() {
    return await evaluateAndReturn(this.page, () => WPP.conn.isMainReady());
  }

  /**
   * Retrieve if is authenticated
   * @category Host
   */
  public async isAuthenticated() {
    return await evaluateAndReturn(this.page, () => WPP.conn.isAuthenticated());
  }

  /**
   * Retrieve if main interface is authenticated and loaded, bot not synced
   * @category Host
   */
  public async isMainLoaded() {
    return await evaluateAndReturn(this.page, () => WPP.conn.isMainLoaded());
  }

  /**
   * Retrieve if main interface is initializing
   * @category Host
   */
  public async isMainInit() {
    return await evaluateAndReturn(this.page, () => WPP.conn.isMainInit());
  }

  /**
   * Join or leave of WhatsApp Web beta program.
   * Will return the value seted
   * @category Host
   */
  public async joinWebBeta(value: boolean): Promise<boolean> {
    return await evaluateAndReturn(
      this.page,
      (value) => WPP.conn.joinWebBeta(value),
      value
    );
  }
  /**
   * Get WhatsApp build constants
   * @category Host
   * @returns Build constants information
   */
  public async getBuildConstants() {
    return await evaluateAndReturn(this.page, () =>
      WPP.conn.getBuildConstants()
    );
  }

  /**
   * Check if the account has been migrated to LID
   * @category Host
   * @returns true if the account has been migrated to LID, false otherwise
   */
  public async isLidMigrated(): Promise<boolean> {
    return await evaluateAndReturn(
      this.page,
      () => WPP.whatsapp.functions.isLidMigrated() as boolean
    );
  }
}

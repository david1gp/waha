/*
 * This file is part of WPPConnect.
 *
 * WPPConnect is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WPPConnect is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with WPPConnect.  If not, see <https://www.gnu.org/licenses/>.
 */

import * as ChromeLauncher from 'chrome-launcher';
import * as os from 'os';
import * as path from 'path';
import * as rimraf from 'rimraf';
import * as waVersion from '@wppconnect/wa-version';
import axios from 'axios';
import { Browser, BrowserContext, Page } from 'puppeteer';
import puppeteer from 'puppeteer-extra';
import { CreateConfig } from '../config/create-config';
import { puppeteerConfig } from '../config/puppeteer.config';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { useragentOverride } from '../config/WAuserAgente';
import { WebSocketTransport } from './websocket';
import { Logger } from 'winston';
import { SessionToken } from '../token-store';
import { LoadingScreenCallback } from '../api/model';
import { LogLevel } from '../utils/logger';

const treeKill = require('tree-kill') as (
  pid: number,
  signal?: string,
  callback?: (error?: Error) => void
) => void;

export async function unregisterServiceWorker(page: Page) {
  await page.evaluateOnNewDocument(() => {
    // Remove existent service worker
    navigator.serviceWorker
      .getRegistrations()
      .then((registrations) => {
        for (let registration of registrations) {
          registration.unregister();
        }
      })
      .catch((err) => null);

    // Disable service worker registration
    // @ts-ignore
    navigator.serviceWorker.register = new Promise(() => {});

    // Assign once per document; re-running this on an interval only wakes the
    // renderer every 500ms for no benefit
    window.onerror = console.error;
    window.onunhandledrejection = console.error;
  });
}

/**
 * Força o carregamento de uma versão específica do WhatsApp WEB
 * @param page Página a ser injetada
 * @param version Versão ou expressão semver
 */
export async function setWhatsappVersion(
  page: Page,
  version: string,
  log?: (level: LogLevel, message: string, meta?: object) => any
) {
  let body: string | null = null;
  try {
    body = waVersion.getPageContent(version);
  } catch (error) {}

  if (!body) {
    log?.(
      'error',
      `Version not available for ${version}, using latest as fallback`
    );
    return;
  }

  await page.setRequestInterception(true);

  page.on('request', (req) => {
    if (req.url().startsWith('https://web.whatsapp.com/check-update')) {
      req.abort();
      return;
    }
    if (req.url() !== 'https://web.whatsapp.com/') {
      req.continue();
      return;
    }

    req.respond({
      status: 200,
      contentType: 'text/html',
      body: body,
    });
  });
}

export async function initWhatsapp(
  page: Page,
  token?: SessionToken,
  clear = true,
  version?: string,
  proxy?: {
    url: string;
    username: string;
    password: string;
  },
  log?: (level: LogLevel, message: string, meta?: object) => any
) {
  if (proxy) {
    await page.authenticate({
      username: proxy.username,
      password: proxy.password,
    });
  }

  await page.setUserAgent(useragentOverride);

  await unregisterServiceWorker(page);

  if (version) {
    log?.('verbose', `Setting WhatsApp WEB version to ${version}`);
    await setWhatsappVersion(page, version, log);
  }

  log?.('verbose', `Loading WhatsApp WEB`);
  await page.goto(puppeteerConfig.whatsappUrl, {
    waitUntil: 'load',
    timeout: 0,
    referer: 'https://whatsapp.com/',
  });

  log?.('verbose', 'WhatsApp WEB loaded');
  /*setTimeout(() => {
    log?.('verbose', `Loading WhatsApp WEB`);

    const timeout = 10 * 1000;
    page
      .goto(puppeteerConfig.whatsappUrl, {
        timeout,
        waitUntil: 'domcontentloaded',
      })
      .catch(() => {});

    log?.('verbose', `WhatsApp WEB loaded`);
  }, 1000);
  */

  return page;
}

let lastPercent = null;
let lastPercentMessage = null;
export async function onLoadingScreen(
  page: Page,
  onLoadingScreenCallBack?: LoadingScreenCallback
) {
  await page.evaluate(`function getElementByXpath(path) {
    return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  }`);

  await page
    .exposeFunction(
      'loadingScreen',
      async (percent: number, message: string) => {
        if (lastPercent !== percent || lastPercentMessage !== message) {
          onLoadingScreenCallBack && onLoadingScreenCallBack(percent, message);
          lastPercent = percent;
          lastPercentMessage = message;
        }
      }
    )
    .catch(() => null);

  await page.evaluate(
    function (selectors) {
      let observer = new MutationObserver(function () {
        let window2: any = window;

        let progressBar = window2.getElementByXpath(selectors.PROGRESS);
        let progressBarNewTheme = window2.getElementByXpath(
          selectors.PROGRESS_NEW_THEME
        );
        let progressMessage = window2.getElementByXpath(
          selectors.PROGRESS_MESSAGE
        );
        let progressMessageNewTheme = window2.getElementByXpath(
          selectors.PROGRESS_MESSAGE_NEW_THEME
        );

        if (progressBar) {
          if (
            this.lastPercent !== progressBar.value ||
            this.lastPercentMessage !== progressMessage.innerText
          ) {
            window2.loadingScreen(progressBar.value, progressMessage.innerText);
            this.lastPercent = progressBar.value;
            this.lastPercentMessage = progressMessage.innerText;
          }
        } else if (progressBarNewTheme) {
          if (
            this.lastPercent !== progressBarNewTheme.value ||
            this.lastPercentMessage !== progressMessageNewTheme.innerText
          ) {
            const progressMsg =
              progressMessageNewTheme.innerText != 'WhatsApp'
                ? progressMessageNewTheme.innerText
                : '';
            window2.loadingScreen(progressBarNewTheme.value, progressMsg);
            this.lastPercent = progressBarNewTheme.value;
            this.lastPercentMessage = progressMsg;
          }
        }
      });

      observer.observe(document, {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true,
      });
    },
    {
      PROGRESS: "//*[@id='app']/div/div/div[2]/progress",
      PROGRESS_NEW_THEME: "//*[@id='app']/div/div/div[3]/progress",
      PROGRESS_MESSAGE: "//*[@id='app']/div/div/div[3]",
      PROGRESS_MESSAGE_NEW_THEME: "//*[@id='app']/div/div/div[2]",
    }
  );
}

export interface WaitForReadyOptions {
  /** Milliseconds; 0 waits until ready, aborted or closed */
  timeout?: number;
  /** Epoch ms the timeout counts from; defaults to the call time */
  startedAt?: number;
  signal?: AbortSignal;
}

export interface InjectApiOptions extends WaitForReadyOptions {
  /** Assigned to window.WPPConfig before wa-js loads */
  config?: object;
}

export class InjectionTimeoutError extends Error {
  name = 'InjectionTimeoutError';

  constructor(readonly timeout: number, options?: ErrorOptions) {
    super(`WPP.isReady not reached after ${timeout}ms`, options);
  }
}

const isTimeoutError = (error: unknown) =>
  error instanceof Error && error.name === 'TimeoutError';

/**
 * Waits for WAPI, Store and WPP.isReady on the current document
 */
export async function waitForWppReady(
  page: Page,
  options: WaitForReadyOptions = {}
): Promise<void> {
  // Explicit timeout so puppeteer's 30s default never applies
  const timeout = options.timeout ?? 0;
  const startedAt = options.startedAt ?? Date.now();
  const deadline = timeout > 0 ? startedAt + timeout : Infinity;

  // puppeteer ignores a signal that is already aborted
  options.signal?.throwIfAborted();

  try {
    await page.waitForFunction(
      () => {
        return (
          typeof window.WAPI !== 'undefined' &&
          typeof window.Store !== 'undefined' &&
          !!window.WPP?.isReady
        );
      },
      {
        // 0 would mean no limit to puppeteer
        timeout: deadline === Infinity ? 0 : Math.max(deadline - Date.now(), 1),
        signal: options.signal,
      }
    );
  } catch (error) {
    if (isTimeoutError(error)) {
      throw new InjectionTimeoutError(timeout, { cause: error });
    }
    // puppeteer's own 30s wait for an execution context: still loading
    if (isTimeoutError((error as Error)?.cause) && !page.isClosed()) {
      return waitForWppReady(page, { ...options, startedAt });
    }
    throw error;
  }
}

export async function injectApi(
  page: Page,
  onLoadingScreenCallBack?: LoadingScreenCallback,
  options: InjectApiOptions = {}
) {
  const timeout = options.timeout ?? 0;
  const startedAt = options.startedAt ?? Date.now();

  // Stops the remaining steps once superseded or out of time
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (options.signal?.aborted) abort();
  options.signal?.addEventListener('abort', abort);

  let timer: NodeJS.Timeout;
  const expired = new Promise<never>((_, reject) => {
    if (timeout > 0) {
      timer = setTimeout(() => {
        reject(new InjectionTimeoutError(timeout));
        abort();
      }, startedAt + timeout - Date.now());
    }
  });

  try {
    // A step stuck in a starved renderer must not stretch the deadline
    await Promise.race([
      runInjection(page, onLoadingScreenCallBack, {
        ...options,
        startedAt,
        signal: controller.signal,
      }),
      expired,
    ]);
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener('abort', abort);
  }
}

async function runInjection(
  page: Page,
  onLoadingScreenCallBack: LoadingScreenCallback | undefined,
  options: InjectApiOptions
) {
  const { signal } = options;

  if (options.config) {
    await page.evaluate((config) => {
      (window as any).WPPConfig = config;
    }, options.config);
  }

  const injected = await page
    .evaluate(() => {
      // wapi.js defines WAPI and Store even when wa-js is missing
      return (
        typeof window.WPP !== 'undefined' &&
        typeof window.WAPI !== 'undefined' &&
        typeof window.Store !== 'undefined'
      );
    })
    .catch(() => false);

  // Stop between steps so a superseded injection does not keep writing
  if (!injected) {
    signal?.throwIfAborted();
    await page.addScriptTag({
      path: require.resolve('@wppconnect/wa-js'),
    });

    signal?.throwIfAborted();
    await page.evaluate(() => {
      WPP.chat.defaultSendMessageOptions.createChat = true;
      WPP.conn.setKeepAlive(true);
    });

    signal?.throwIfAborted();
    await page.addScriptTag({
      path: require.resolve(
        path.join(__dirname, '../../dist/lib/wapi', 'wapi.js')
      ),
    });

    signal?.throwIfAborted();
    await onLoadingScreen(page, onLoadingScreenCallBack);
  }

  // Make sure WAPI is initialized
  await waitForWppReady(page, options);
}

/**
 * Resolves the Chromium launch arguments.
 *
 * When the caller passes no arguments (or an empty list) the default
 * `puppeteerConfig.chromiumArgs` are used. A non-empty list replaces the
 * defaults, matching the existing `browserArgs` contract. The default list only
 * contains launch and performance flags; the flags that disable browser
 * protections live in `puppeteerConfig.protectionDisablingChromiumArgs` and are
 * only merged in when `useInsecureChromiumArgs` is explicitly enabled.
 */
export function resolveBrowserArgs(
  requested?: string[],
  useInsecure = false
): string[] {
  const args = [
    ...(requested?.length ? requested : puppeteerConfig.chromiumArgs),
  ];

  if (useInsecure) {
    for (const arg of puppeteerConfig.protectionDisablingChromiumArgs) {
      if (!args.includes(arg)) {
        args.push(arg);
      }
    }
  }

  return args;
}

/**
 * Initializes browser, will try to use chrome as default
 * @param session
 */
export async function initBrowser(
  session: string,
  options: CreateConfig,
  logger: Logger
): Promise<Browser> {
  if (options.useChrome) {
    const chromePath = getChrome();
    if (chromePath) {
      if (!options.puppeteerOptions) {
        options.puppeteerOptions = {};
      }
      options.puppeteerOptions.executablePath = chromePath;
    } else {
      logger.warn('Chrome not found, using chromium', {
        session,
        type: 'browser',
      });
    }
  }

  // Use stealth plugin to avoid being detected as a bot
  puppeteer.use(StealthPlugin());

  let browser = null;
  if (options.browserWS && options.browserWS != '') {
    const transport = await getTransport(options.browserWS);
    browser = await puppeteer.connect({ transport });
  } else {
    /**
     * Setting the headless mode to the old Puppeteer mode, when using the 'new' mode, results in an error on CentOS7 and Debian11.
     * Temporary fix.
     *
     * If proxy settings are provided, they are applied to the browser launch arguments.
     * This allows the browser to use the specified proxy server for all network requests.
     */

    const args = resolveBrowserArgs(
      options.browserArgs,
      options.useInsecureChromiumArgs
    );
    if (options.proxy && options.proxy.url) {
      args.push(`--proxy-server=${options.proxy.url}`);
    }

    browser = await puppeteer.launch({
      headless: options.headless,
      devtools: options.devtools,
      args,
      ...options.puppeteerOptions,
    });

    // Register an exit callback to remove user-data-dir
    try {
      const arg = browser
        .process()
        .spawnargs.find((s: string) => s.startsWith('--user-data-dir='));

      if (arg) {
        const tmpUserDataDir = arg.split('=')[1];

        // Only if path is in TMP directory
        if (
          path.relative(os.tmpdir(), tmpUserDataDir).startsWith('puppeteer')
        ) {
          process.on('exit', () => {
            // Remove only on exit signal
            try {
              rimraf.sync(tmpUserDataDir);
            } catch (error) {}
          });
        }
      }
    } catch (error) {}
  }

  return browser;
}

/**
 * Closes a browser and, when it was launched by this process, guarantees its
 * OS process tree is terminated even if the graceful close fails or hangs.
 * Remote browsers (`browserWS`) expose no process handle and are only
 * disconnected. Safe to call when the page/browser was already closed.
 */
export async function closeBrowser(browser: Browser): Promise<void> {
  // Only browsers launched by this process expose a process handle
  const pid = browser.process?.()?.pid;

  if (!pid) {
    // Caller-supplied remote connection: detach this client only. Closing it
    // would terminate the browser shared with every other connected client.
    // Connections that expose neither a process handle nor a disconnect method
    // (e.g. test doubles) fall back to close().
    if (typeof browser.disconnect === 'function') {
      await browser.disconnect().catch(() => null);
    } else {
      await browser.close().catch(() => null);
    }
    return;
  }

  const gracefulClose = browser.close().catch(() => null);

  // Bound the graceful close so an unresponsive browser cannot hang teardown
  let timer: NodeJS.Timeout;
  const timedOut = new Promise<void>((resolve) => {
    timer = setTimeout(resolve, 5000);
  });
  try {
    await Promise.race([gracefulClose, timedOut]);
  } finally {
    clearTimeout(timer);
  }

  // Force kill the process tree if the graceful close did not take it down
  await new Promise<void>((resolve) => {
    treeKill(pid, 'SIGKILL', () => resolve());
  });
}

export async function getOrCreatePage(
  browser: Browser | BrowserContext
): Promise<Page> {
  const pages = await browser.pages();

  if (pages.length) {
    return pages[0];
  }

  return await browser.newPage();
}

/**
 * Returns whether at least one open, non-blank page remains.
 *
 * Puppeteer commonly leaves an `about:blank` tab behind after the session page
 * is closed, so a non-empty `browser.pages()` does not prove a real page is
 * still alive. This drives the auto-close guard in `create()`.
 */
export function hasAlivePage(pages: Page[]): boolean {
  return pages.some((page) => !page.isClosed() && page.url() !== 'about:blank');
}

/**
 * Retrieves chrome instance path
 */
function getChrome() {
  try {
    return ChromeLauncher.Launcher.getFirstInstallation();
  } catch (error) {
    return undefined;
  }
}

async function getTransport(browserWS: string) {
  let error = null;
  try {
    return await WebSocketTransport.create(browserWS, 10000);
  } catch (e) {
    error = e;
  }

  // Automatic get the endpoint
  try {
    const endpointURL =
      browserWS.replace(/ws(s)?:/, 'http$1:') + '/json/version';
    const data = await axios.get<any>(endpointURL).then((r) => r.data);

    return await WebSocketTransport.create(data.webSocketDebuggerUrl, 10000);
  } catch (e) {}

  // Throw first error
  throw error;
}
